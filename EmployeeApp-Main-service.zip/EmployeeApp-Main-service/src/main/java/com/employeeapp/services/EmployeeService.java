package com.employeeapp.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeeapp.entities.Employee;
import com.employeeapp.exception.EmployeeServiceException;
import com.employeeapp.repositories.EmployeeServiceRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeServiceRepository repo;
	

	public List<Employee> getAllEmployees() {
		return repo.findAll();
	}


	public Employee getEmployeebyId(int id) throws EmployeeServiceException {
		Optional<Employee> optional = repo.findById(id);

		if (optional.isEmpty()) {
			throw new EmployeeServiceException("Employee not found with id: " + id);
		} else {
			return optional.get();
		}
	}

	public Employee saveEmployee(Employee employee) {
		return repo.save(employee);
	}

	public Employee updateEmployee(Employee employee) throws EmployeeServiceException {
		if (repo.existsById(employee.getId())) {
			return repo.save(employee);
		} else {
			throw new EmployeeServiceException("Employee is not found with Id: " + employee.getId());
		}

	}

	public String delete(int id) throws EmployeeServiceException {

		Optional<Employee> optional = repo.findById(id);

		if (optional.isEmpty()) {
			throw new EmployeeServiceException("Employee not found with id: " + id);
		} else {
			repo.deleteById(id);
			return "Employee is deleted Successfully!!";
		}
	}

}
