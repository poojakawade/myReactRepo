package com.employeeapp.exception.handler;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.employeeapp.exception.EmployeeServiceException;


@ControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(EmployeeServiceException.class)
	public ResponseEntity<?> handleException(EmployeeServiceException e) {
		return ResponseEntity.ok(new ErrorResponse(e.getMessage(), e.getClass().toString()));
	}
}
