package com.employeeapp.exception;

public class EmployeeServiceException extends Exception {

	public EmployeeServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeServiceException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public EmployeeServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EmployeeServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EmployeeServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
