package com.employeeapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.employeeapp.entities.Employee;
import com.employeeapp.exception.EmployeeServiceException;
import com.employeeapp.services.EmployeeService;

@RestController
// @CrossOrigin(origins = {"https://hoppscotch.io"})
//@CrossOrigin("*")
@RequestMapping("/api/v1/emp")
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	
	@GetMapping("/getemployees")
	public List<Employee> getAllEmployees() {
		return service.getAllEmployees();
	}

	
	@PostMapping("/saveemp")
	public Employee saveEmployee(@RequestBody Employee employee) {
		return service.saveEmployee(employee);
	}
	
	@GetMapping("/getemployees/{id}")
	public Employee getEmployeebyId(@PathVariable int id) throws EmployeeServiceException {
		return service.getEmployeebyId(id);
	}

	@PutMapping("/updateemployees")
	public Employee updateEmployee(@RequestBody Employee employee) throws EmployeeServiceException {
		return service.updateEmployee(employee);
	}
	
	@DeleteMapping("/deleteemployees/{id}") 
	@ResponseBody
	public String delete(@PathVariable int id) throws EmployeeServiceException 
	{  
		return service.delete(id);
	}
	 

}
