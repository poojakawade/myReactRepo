package com.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;


import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;


import com.employeeapp.EmployeeServiceApplication;

//@RunWith(SpringRunner.class)
@SpringBootTest(classes = EmployeeServiceApplication.class)
class EmployeeServiceApplicationTests {

	@Test
	void contextLoads() {
	}
	
//	@Autowired
//	private EmployeeService empService;
//	
//	@MockBean
//	private BookServiceRepository bookServiceRepository;
//	
//	@Test
//	public void getbooksTest() {
//	
//		when(bookServiceRepository.findAll()).thenReturn(Stream.of(new Book(123,"Mr. Right","comic", 
//				270, "Mark Lay", "lay publisher", "Okay", "Active",4,"https://picsum.photos/250?image=9"),new Book(25,"Princess","comic", 
//						450, "Mark J", "J publisher", "Okay Good", "Active",6,"https://docs.flutter.dev/assets/images/dash/dash-fainting.gif")).collect(Collectors.toList()));
//		
//		assertEquals(2, empService.getAllBooks().size());
//	}
//	
//	@Test
//	public void getbooksbyCriteria() {
//	
//		when(bookServiceRepository.findByCategoryAndAuthorAndPriceAndPublisherAndStatus("comic", "Mr John", 300, "R publisher", "active")).thenReturn(Stream.of(new Book(123,"Mr. Right","comic", 
//				270, "Mark Lay", "lay publisher", "Okay", "Active",4,"https://picsum.photos/250?image=9")).collect(Collectors.toList()));
//		
//		assertEquals(1, empService.findBycategoryAndauthorAndpriceAndpublisher("comic", "Mr John", 300, "R publisher","active").size());
//	}
//	
//	@Test
//	public void saveBook() {
//		
//		Book book = new Book(25,"Princess","comic", 
//				450, "Mark J", "J publisher", "Okay Good", "Active",6,"https://docs.flutter.dev/assets/images/dash/dash-fainting.gif");
//		when(bookServiceRepository.save(book)).thenReturn(book);
//		assertEquals(book, empService.saveBook(book));
//	}
//	
	

}
