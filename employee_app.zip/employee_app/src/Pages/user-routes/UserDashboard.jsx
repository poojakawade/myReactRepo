import React from 'react'
import Base from '../../components/Base'
import ListEmployee from '../../components/ListEmployee'

const UserDashboard=()=> {
  return (
    <Base>
    <div className="container">
    <ListEmployee />
    </div>
    </Base>
  )
}

export default UserDashboard