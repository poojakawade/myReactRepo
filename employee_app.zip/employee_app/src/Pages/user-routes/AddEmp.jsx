import React from 'react'
import AddEmployee from '../../components/AddEmployee'
import Base from '../../components/Base'

const AddEmp=()=> {
  return (
    <Base>
    <div className="container">
    <AddEmployee />
    </div>
    </Base>
  )
}

export default AddEmp