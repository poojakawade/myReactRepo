import React, { useContext, useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router'
import { toast } from 'react-toastify'
import Base from '../../components/Base'
import { Button, Card, CardBody, CardHeader, Col, Container, Form, FormGroup, Input, Label, Row } from "reactstrap";
import userContext from '../../context/userContext'
import { getEmp, updateEmp } from '../../services/addEmpService'
import { gteCurrentUserDetail } from '../../Auth';

function UpdataEmp() {

  const {id} = useParams()
  const object = useContext(userContext)
  const navigate = useNavigate();
  const[emp,setEmp]=useState(null)

  //on cancel
  const cancel=()=>{
      //redirect tolist of employees page
      navigate("/user/dashboard")
  }

  const handleChange=(event,fieldName)=>{
    setEmp({...emp,[fieldName]:event.target.value})

}
  
  useEffect(()=>{
      //console.log(id)
      getEmp(id).then(data=>{
        setEmp({...data})
      }).catch(error=>{
        console.log(error)
        toast.error("Error while loading Employee")
      })
  },[])

  const updateEmployee=(event)=>{
      event.preventDefault();
      console.log(emp)
      console.log(id)
      updateEmp({...emp},id).then(res=>{
          console.log(res)
          toast.success("Employee Updated")
          navigate("/user/dashboard")
      }).catch(error=>{
          console.log(error)
          toast.error("Error while updating Employee")
      })
  }

  const updateHtml=()=>{
      return(
        <Container>
        <Row className="mt-4">
            <Col sm={{size:6,offset:3}}> 
            <Card color="dark" outline>
                {/* {JSON.stringify(add)} */}
            <CardHeader>
                <h3>Update Employee Information</h3>
            </CardHeader>
            <CardBody>
                <Form onSubmit={updateEmployee}>
                    <FormGroup>
                        <Label for="firstName">First Name: </Label>
                        <Input type="text" placeholder="Enter First Name" id="firstName" 
                       name="firstName" value={emp.firstName} onChange={(event)=>handleChange(event,'firstName')}/>
                    </FormGroup>
                    <FormGroup>
                        <Label for="lastName">Last Name: </Label>
                        <Input type="text" placeholder="Enter Last Name" id="lastName" 
                        name="lastName" value={emp.lastName} onChange={(event)=>handleChange(event,'lastName')}/>
                    </FormGroup>
                    <FormGroup>
                        <Label for="email">Email Id: </Label>
                        <Input type="email" placeholder="Enter Email Id" id="email" 
                        name="emailId" value={emp.emailId} onChange={(event)=>handleChange(event,'emailId')}/>
                    </FormGroup>
                
                    <Container className="text-center">
                        <Button rype="submit" color="primary">Update</Button>
                        <Button onClick={cancel} color="danger" className="ms-2" type ="cancel">Cancel</Button>
                    </Container>
                </Form>
            </CardBody>
        </Card>
            </Col>
        </Row>
    </Container>
      )
  }

  return (
    <Base>
        {emp && updateHtml()}
    </Base>
  )
}

export default UpdataEmp