import React, { useContext, useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router'
import { toast } from 'react-toastify'
import { Button, Card, CardBody, CardFooter, Col, Container, Input, Row, Table } from 'reactstrap'
import { gteCurrentUserDetail, isloggedIn } from '../../Auth'
import Base from '../../components/Base'
import userContext from '../../context/userContext'
import { getUser, updateUser } from '../../services/user-service'

function ProfileInfo() {
  const navigate = useNavigate()
  const [currentUser,setCurrentUser]=useState(null);
  const [login,setLogin]=useState(null);
  useEffect(()=>{
    setCurrentUser(gteCurrentUserDetail())
    setLogin(isloggedIn())
  },[])

  const object = useContext(userContext)
  const [user,setUser]=useState(null)
  const {userId}=useParams();

  useEffect(()=>{
    console.log(userId)
    getUser(userId).then(data=>{
      console.log(data)
      setUser({...data})
      console.log(user)
    })
  },[])

  const handleChange=(event,fieldName)=>{
    setUser({...user,[fieldName]:event.target.value})

}

const onUpdateUser=(event)=>{
  event.preventDefault();
  updateUser({...user},userId).then(res=>{
      console.log(res)
      toast.success("User Updated")
      {event.target.password=''}
      //window.location.reload(false)
      navigate("/user/dashboard")
  }).catch(error=>{
      console.log(error)
      toast.error("Error while updating Employee")
  })
}

  const UserView=()=>{
    return(
      <Row>
        <Col md={{size:8,offset:2}}>
          <Card className='mt-2 border-0 rounded-0 shadow-sm'>
            <CardBody>
              <h3 className='text-center text-uppercase'>***User Profile***</h3>
              <Container className='text-center'>
                <img style={{maxWidth:'200px',maxHeight:'200px'}} 
                src="https://www.pngitem.com/pimgs/m/22-223968_default-profile-picture-circle-hd-png-download.png"
                 alt="user profile pic" className='img-fluid rounded-circle'></img>
              </Container>
              <Table responsive striped hover bordered={true} className='text-left mt-5'>
                <tbody>
                  <tr>
                    <td >Id:
                    </td>
                    <td>{user.id}</td>
                  </tr>
                  <tr>
                    <td>User Name:
                    </td>
                    <td> <Input type="text" placeholder="Enter User Name" id="username" 
                       name="username" value={user.username} /></td>
                  </tr>
                  <tr>
                    <td>Email Id:
                    </td>
                    <td><Input type="email" placeholder="Enter Email Id" id="email" 
                       name="email" value={user.email} /></td>
                  </tr>
                  <tr>
                    <td>Password:
                    </td>
                    <td><Input type="password" placeholder="Enter New Password" id="password" 
                       name="password"  onChange={(event)=>handleChange(event,'password')}/></td>
                  </tr>
                </tbody>

              </Table>
              {currentUser ? (currentUser.id==user.id)?((<CardFooter className='text-center'>
                <Button onClick={onUpdateUser} color='warning'>Update Profile</Button>
              </CardFooter>
              )):'':''}
            </CardBody>
          </Card>
        </Col>
      </Row>
    )
  }

  return (
   <Base>
         {user?UserView():'loading user data'}
   </Base>
  )
}

export default ProfileInfo