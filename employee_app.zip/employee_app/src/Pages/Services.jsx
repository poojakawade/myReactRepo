import Base from "../components/Base";

const Services=()=>{
    return(

        <Base>
        <h1>This is services page</h1>
        </Base>
    )
};
export default Services;