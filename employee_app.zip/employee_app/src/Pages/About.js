import Base from "../components/Base";
import userContext from "../context/userContext";

const About=()=>{
    return (
       <userContext.Consumer>
           {
               (object)=>(
                <Base>
                <h1>This is About us</h1>
                <p>We are building employee website</p>
                {console.log(object)}
                <h3>Welcome User: {object.user.login && object.user.data.username}</h3>
                </Base>
               )
           }
       </userContext.Consumer>
    )
};

export default About;