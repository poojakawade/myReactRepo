import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Base from './components/Base';
import { BrowserRouter,Routes,Route } from 'react-router-dom';
import Home from './Pages/Home';
import Login from './Pages/Login';
import Signup from './Pages/Signup';
import About from './Pages/About';
import Services from './Pages/Services';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import UserDashboard from './Pages/user-routes/UserDashboard';
import PrivateRoute from './components/PrivateRoute';
import ProfileInfo from './Pages/user-routes/ProfileInfo';
import AddEmp from './Pages/user-routes/AddEmp';
import UserProvider from './context/UserProvider';
import UpdataEmp from './Pages/user-routes/UpdataEmp';


function App() {
  return (
    <UserProvider>
   <BrowserRouter>
   <ToastContainer position="top-center"/>
   <Routes>
    <Route path="/" element={<Home />}/>
    <Route path="/login" element={<Login />}/>
    <Route path="/signup" element={<Signup />}/>
    <Route path="/about" element={<About />}/>
    <Route path="/services" element={<Services />}/>

    <Route path="/user" element={<PrivateRoute />}>

      <Route path="dashboard" exact element={<UserDashboard />}/>
      <Route path="profile-info/:userId" element={<ProfileInfo />}/>
      <Route path="addemployee" element={<AddEmp />}/>
      <Route path="updateemployee/:id" element={<UpdataEmp />}/>


    </Route>
    
   </Routes>
   </BrowserRouter>
   </UserProvider>

   
  );
}

export default App;
