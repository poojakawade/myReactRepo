//isloggedIn
export const isloggedIn=()=>{
    let data = localStorage.getItem("data")
    if(data==null){
        return false;
    }else{
        return true;
    }
}

//doLogin=>data=>set to localstorage
export const doLogin=(data,next)=>{
    localStorage.setItem("data",JSON.stringify(data));
    next();
}


//doLogout=> remove from local storage
export const doLogout=(next)=>{
    localStorage.removeItem("data")
    next();
}


//getCurrentUser
export const gteCurrentUserDetail=()=>{
    if(isloggedIn()){
        return JSON.parse(localStorage.getItem("data"));
    }else{
        return undefined;
    }
}

export const getToken=()=>{
    if(isloggedIn()){
        return JSON.parse(localStorage.getItem("data"))?.accessToken;
       
    }
    return null;
}