import React, { useEffect, useState } from 'react'
import { gteCurrentUserDetail, isloggedIn } from '../Auth'
import userContext from './userContext'

function UserProvider({children}) {

    const [user, setUser]=useState({
        data:{},
        login:false
    })

    useEffect(()=>{

      setUser({
        data:gteCurrentUserDetail(),
        login:isloggedIn()
      })
    },[])

  return (
    <userContext.Provider value={{user,setUser}}>
        {children}
    </userContext.Provider>
  )
}

export default UserProvider