import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { toast } from "react-toastify";
import { Button, Card, CardBody, CardHeader, Col, Container, Form, FormFeedback, FormGroup, Input, Label, Row } from "reactstrap";
import { gteCurrentUserDetail } from "../Auth";
import { addEmp } from "../services/addEmpService";

const AddEmployee=()=>{

    const navigate=useNavigate()
    const [user,setUser]=useState(undefined)

    const [add, setAdd]=useState({
        firstName:'',
        lastName:'',
        emailId:''

    })

    useEffect(
        ()=>{
            setUser(gteCurrentUserDetail())
        },[]
    )

    //on cancel
    const cancel=()=>{
        //redirect tolist of employees page
        navigate("/user/dashboard")
    }

    //field changed function
    const fieldChanged=(event)=>{
        setAdd({...add,[event.target.name]:event.target.value})

    }

    const handleReset=()=>{
        setAdd({
                emailId:"",
                firstName:"",
                lastName:""
        });
    }

    //create employee function
    const createEmp=(event)=>{
        event.preventDefault();

        if(add.firstName.trim()==''){
            toast.error("First Name is required!!")
            return;
        }
        if(add.lastName.trim()==''){
            toast.error("Last Name is required!!")
            return;
        }
        if(add.emailId.trim()==''){
            toast.error("email Id is required!!")
            return;
        }

        //submit the form on server
        addEmp(add).then(data=>{
            toast.success("Employee is added successfully !!")
            console.log(add)
            handleReset();
            navigate("/user/dashboard")
            //console.log(add)
        }).catch((error)=>{
            //console.log(error)
            toast.error("Employee is not added due to some error !!")
        })
    }

    return (
        <Container>
            <Row className="mt-4">
                <Col sm={{size:6,offset:3}}> 
                <Card color="dark" outline>
                    {/* {JSON.stringify(add)} */}
                <CardHeader>
                    <h3>Add New Employee</h3>
                </CardHeader>
                <CardBody>
                    <Form onSubmit={createEmp}>
                        <FormGroup>
                            <Label for="firstName">First Name: </Label>
                            <Input type="text" placeholder="Enter First Name" id="firstName" 
                            value={add.firstName} name="firstName" onChange={fieldChanged}/>
                        </FormGroup>
                        <FormGroup>
                            <Label for="lastName">Last Name: </Label>
                            <Input type="text" placeholder="Enter Last Name" id="lastName" 
                            value={add.lastName} name="lastName" onChange={fieldChanged}/>
                        </FormGroup>
                        <FormGroup>
                            <Label for="email">Email Id: </Label>
                            <Input type="email" placeholder="Enter Email Id" id="email" 
                            value={add.emailId} name="emailId" onChange={fieldChanged}/>
                        </FormGroup>
                    
                        <Container className="text-center">
                            <Button rype="submit" color="primary">Add</Button>
                            <Button onClick={cancel} color="danger" className="ms-2" type ="cancel">Cancel</Button>
                        </Container>
                    </Form>
                </CardBody>
            </Card>
                </Col>
            </Row>
        </Container>
    )
}

export default AddEmployee