import React, { Component } from 'react'
import PropTypes from 'prop-types'
import EmployeeService from '../services/EmployeeService'
import { Link } from 'react-router-dom'
import { deleteEmp } from '../services/addEmpService'
import { toast } from 'react-toastify'
import { Button } from 'reactstrap'

/**
* @author
* @class ListEmployee
**/

class ListEmployee extends Component {
constructor(props){
    super(props)
    this.state = {
        employees:[]
    }
    //this.addEmployee= this.addEmployee.bind(this);
}
 componentDidMount(){
     EmployeeService.getEmployees().then((resp)=>{
        this.setState({employees:resp.data});
     });
 }

//  addEmployee(){
//      this.props.history.push('/user/addemployee');
//  }

 //function to delete post
deleteEmployee(id){
    deleteEmp(id).then(res=>{
        console.log(res);
        toast.success("Employee is deleted..")
        this.componentDidMount()
    }).catch(error=>{
        console.log(error)
        toast.error("Error while deleting Employee")
    })

 }

 render() {
  return(
   <div>
       <div border="1px solid black">
       <h2 className="text-center">List of Employees</h2>
       </div>
       <div className="">
       <Link to="/user/addemployee" className="btn btn-secondary">Add Employee</Link>
        {/* <button type="button" className="btn btn-primary" onClick={this.addEmployee}>Add Employee</button> */}
       </div>
       <hr />
       <div className="row">
           <table className="table table-striped table-bordered ">
               <thead>
                   <tr>
                       <th>Employee Id</th>
                       <th>First name</th>
                       <th>Last name</th>
                       <th>Email Id</th>
                       <th>Update</th>
                       <th>Delete</th>
                   </tr>
               </thead>

               <tbody>
                    {
                        this.state.employees.map(
                            employee=>
                            <tr key={employee.id}>
                                <td>{employee.id}</td>
                                <td>{employee.firstName}</td>
                                <td>{employee.lastName}</td>
                                <td>{employee.emailId}</td>
                                <td>
                                <Button tag={Link} to={`/user/updateemployee/${employee.id}`} className="btn btn-primary">Update </Button>
                                </td>
                                <td>
                                <Button onClick={ () => this.deleteEmployee(employee.id)} className="btn btn-danger">Delete </Button>
                                </td>
                            </tr>
                        )
                    }

               </tbody>

           </table>

       </div>

   </div>
    )
   }
 }


ListEmployee.propTypes = {}
export default ListEmployee