import React, { useContext, useEffect, useState } from 'react';
import { NavLink as ReactLink } from 'react-router-dom';

import { Navbar,NavbarBrand,NavbarToggler,Collapse,Nav
    ,NavItem,NavLink,UncontrolledDropdown,DropdownToggle,DropdownMenu,DropdownItem,NavbarText} from "reactstrap";
import { doLogout, gteCurrentUserDetail, isloggedIn } from '../Auth';
import { Navigate, useNavigate } from 'react-router';
import userContext from '../context/userContext';

const CustomNavbar=()=>{

    const userContextData = useContext(userContext);

    let nevigate = useNavigate();
    const [isOpen, setIsOpen] = useState(false);

    const [login,setLogin]=useState(false);
    const [data,setData]=useState(undefined)

    useEffect(()=>{
      setLogin(isloggedIn())
      setData(gteCurrentUserDetail())

    },[login])

    const logout=()=>{
      doLogout(()=>{
        //logged out
        setLogin(false)
        userContextData.setUser({
          data:'',
          login:false
      });

        nevigate("/")
      })
    }

    return(
        <div>
      <Navbar color="dark" dark expand="md" fixed="" className="px-5">
        <NavbarBrand tag={ReactLink} to="/">EmployeeApp</NavbarBrand>
        <NavbarToggler onClick={()=>setIsOpen(!isOpen)} />
        <Collapse isOpen={isOpen} navbar>
          <Nav className="me-auto" navbar>
          <NavItem>
              <NavLink tag={ReactLink} to="/">Home</NavLink>
            </NavItem>
            <NavItem>
              <NavLink tag={ReactLink} to="/about">About</NavLink>
            </NavItem>
            <NavItem>
              <NavLink tag={ReactLink} to="/services">Services</NavLink>
            </NavItem>
            
            <UncontrolledDropdown inNavbar nav>
              <DropdownToggle caret nav>
                More
              </DropdownToggle>
              <DropdownMenu right>
                <DropdownItem tag={ReactLink} to="/services">Contact Us</DropdownItem>
                <DropdownItem>Facebook</DropdownItem>
                <DropdownItem divider />
                <DropdownItem>Youtube</DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </Nav>
          <Nav navbar>
            {
              login && (
                <>
                <NavItem>
                  <NavLink tag={ReactLink} to={`/user/profile-info/${data.id}`}>
                    Profile Info
                  </NavLink>
                </NavItem>

                <NavItem>
                  <NavLink tag={ReactLink} to="/user/dashboard">
                    {data.username}
                  </NavLink>
                </NavItem>

                <NavItem>
                  <NavLink tag={ReactLink} to="/user/addemployee">
                    Add Employees
                  </NavLink>
                </NavItem>

                <NavItem>
                  <NavLink onClick={logout}>
                    Logout
                  </NavLink>
                </NavItem>
                </>
              )
            }
          { !login && (
            <>
            <NavItem>
              <NavLink tag={ReactLink} to="/login">
                Login
              </NavLink>
            </NavItem>
            <NavItem>
              <NavLink tag={ReactLink} to="/signup">
                SignUp
              </NavLink>
            </NavItem>
            </>
          )

          }
          </Nav>
          
        </Collapse>
      </Navbar>
    </div>
    )
};

export default CustomNavbar;