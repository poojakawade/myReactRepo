import React, { Component } from 'react'

export default class Footer extends Component {


  render() {
    return (
      <div>
          <footer className="footer">
              <span className="text-muted">All rights Reserved 2022 @EmployeeApp</span>

          </footer>

      </div>
    )
  }
}
