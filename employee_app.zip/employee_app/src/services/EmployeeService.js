import axios from "axios";
import { privateAxios } from "./helper";


class EmployeeService{

    getEmployees(){
        return privateAxios.get('/getemployees');

    }

}

export default new EmployeeService();