import axios from "axios";
import { getToken } from "../Auth";

export const BASE_URL='http://localhost:9000';
const EMP_BASE_URL = "http://localhost:9000/api/v1/employeeapp/user";

export const myAxios=axios.create({
    baseURL:BASE_URL
});

export const privateAxios=axios.create({
    baseURL:EMP_BASE_URL
});

privateAxios.interceptors.request.use(config=>{
    const token = getToken()
    //console.log(token)
    if(token){
        config.headers = { 
            'Authorization': `Bearer ${token}`,
            'Accept': 'application/json'
          }
        return config
    }
},error=>Promise.reject(error))