import { myAxios, privateAxios } from "./helper";

export const signUp=(user)=>{
    console.log(user);
    return myAxios.post('/api/v1/employeeapp/auth/signup',user).then((response)=>response.data)
};

export const loginUser=(loginDetail)=>{
    return myAxios.post('/api/v1/employeeapp/auth/signin',loginDetail).then((response)=>response.data)

}

export const getUser=(userId)=>{
    console.log(userId)
    return privateAxios.get(`/getUser/${userId}`).then((response)=>response.data)

}

export const updateUser=(user,userId)=>{
    console.log(userId)
    return privateAxios.put(`/update/${userId}`,user).then((response)=>response.data)

}