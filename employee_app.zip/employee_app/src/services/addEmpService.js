import axios from "axios";
import { privateAxios } from "./helper";



export const addEmp=(empData)=>{
    //console.log(empData);
    return privateAxios.post(`/saveemployees`,empData).then((response)=>response.data)
};

export const updateEmp=(empData,id)=>{
    console.log(id);
    return privateAxios.put(`/updateemployees/`+id,empData).then((response)=>response.data)
};

export const deleteEmp=(id)=>{
    console.log(id);
    return privateAxios.delete(`/deleteemployees/${id}`).then((response)=>response.data)
};

export const getEmp=(id)=>{
    //console.log(id);
    return privateAxios.get(`/getemployees/${id}`).then((response)=>response.data)
};