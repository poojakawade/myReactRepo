package com.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.employeeApp.UserServiceApplication;

@SpringBootTest(classes = UserServiceApplication.class)
class UserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
