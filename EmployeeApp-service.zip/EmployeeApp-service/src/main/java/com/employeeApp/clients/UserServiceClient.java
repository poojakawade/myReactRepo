package com.employeeApp.clients;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;


import com.employeeApp.models.Employee;

import feign.Headers;

@FeignClient(name = "EmployeeService", url = "localhost:9191")
public interface UserServiceClient {
	
	@GetMapping("/api/v1/emp/getemployees")
	public List<Employee> getAllEmployees();
	
	@PostMapping("/api/v1/emp/saveemp")
	@Headers("Content-Type: application/json")
	public Employee saveEmployee( Employee employee);
	
	@GetMapping("/api/v1/emp/getemployees/{id}")
	public Employee getEmployeebyId(@PathVariable int id);

	@PutMapping("/api/v1/emp/updateemployees") 
	public Employee updateEmployee(Employee employee);

	@DeleteMapping("/api/v1/emp/deleteemployees/{id}") 
	public String deleteEmployee(@PathVariable int id);

	
}
