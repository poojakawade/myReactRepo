package com.employeeApp.controllers;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.employeeApp.clients.UserServiceClient;
import com.employeeApp.entities.User;
import com.employeeApp.exception.UserServiceException;
import com.employeeApp.services.UserService;
import com.employeeApp.models.Employee;

@RestController
@RequestMapping("/api/v1/employeeapp/user")
//@CrossOrigin("*")
public class UserController {

	@Autowired
	private UserService service;
	
	@Autowired
	private UserServiceClient userServiceClient;
	
	@GetMapping("/getUser/{id}")
	public User getUser(@PathVariable long id) throws UserServiceException {
		return service.getUserById(id);
	}
	
	@PutMapping("/update/{id}")
	public User updateUser(@RequestBody User user,@PathVariable long id) throws UserServiceException {
		user.setId(id);
		return service.updateUser(user);
	}
	
	@GetMapping("/getemployees")
	public List<Employee> getAllEmployees() {
		return userServiceClient.getAllEmployees();
	}
	
	@PostMapping("/saveemployees")
	public Employee saveEmployee(@RequestBody Employee employee) {
		return userServiceClient.saveEmployee(employee);
	}
	
	@GetMapping("/getemployees/{id}")
	public Employee getEmployeebyId(@PathVariable int id) {
		return userServiceClient.getEmployeebyId(id);
	}
	
	@PutMapping("/updateemployees/{id}") 
	 public Employee updateEmployee(@PathVariable int id,@RequestBody Employee employee) {
		employee.setId(id);
		
		 return userServiceClient.updateEmployee(employee); 
		 
	 }
	 
	 @DeleteMapping("/deleteemployees/{id}") 
	 @ResponseBody
	 public String deleteEmployee(@PathVariable int id) {
		 return userServiceClient.deleteEmployee(id); 
		 
	 }
	
	

//	@PostMapping("/signup")
//	public Author saveAuthor(@RequestBody Author author) {
//		return service.saveAuthor(author);
//	}

	
//	 @PostMapping("{authorId}/books") 
//	 public Book saveBook(@PathVariable int authorId,@RequestBody Book book) {
//		 book.setAuthorId(authorId);
//		 return bookServiceClient.SaveBook(book); 
//		 
//	 }
//	 
//	 @PutMapping("{authorId}/books/{bookId}") 
//	 public Book updateBook(@PathVariable int authorId,@PathVariable int bookId,@RequestBody Book book) {
//		 book.setAuthorId(authorId);
//		 book.setId(bookId);
//		 //System.out.println("BookId:"+book.getId());
//		 //System.out.println("Book authorId:"+book.getAuthorId());
//		// kafkaTemplate.send(TOPIC,book);
//		 //System.out.println("Published successfully :"+book.toString());
//		 return bookServiceClient.updateBook(book); 
//		 
//	 }
//	 
//	 @DeleteMapping("/books/{bookId}") 
//	 @ResponseBody
//	 public void deleteBook(@PathVariable int bookId) {
//		 bookServiceClient.deleteBook(bookId); 
//		 
//	 }
	 
	 
	 
	

}
