package com.employeeApp.request;

import java.util.Set;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.UniqueElements;


public class SignupRequest {
	
	@NotEmpty
	@Size(min = 4,max = 20,message="username must be min of 4 characters!!")
	private String username;
	
	@NotEmpty
	@Size(max = 50)
	@Email(message="Email is not valid!!")
	private String email;
	
	private Set<String> Role;
	
	@NotEmpty
	@Size(min=3,max = 10,message="password must be min of 3 chars and max of 10 characters")
	private String password;

	public SignupRequest( String username, String email, Set<String> Role, String password) {
		this.username=username;
		this.email=email;
		this.Role=Role;
		this.password=password;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	

	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Set<String> getRole() {
		return Role;
	}

	public void setRole(Set<String> Role) {
		this.Role = Role;
	}

	public SignupRequest() {
		super();
	}

	
}
