package com.employeeApp.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.employeeApp.repositories.UserServiceRepository;
import com.employeeApp.entities.User;
import com.employeeApp.exception.UserServiceException;



@Service
public class UserService {

   
    @Autowired
    private UserServiceRepository repo;
    
    @Autowired
	PasswordEncoder encoder;
    
    public List<User> getAllUsers(){
        return repo.findAll();
    }
    
    public User getUserById(long id) throws UserServiceException {
		Optional<User> optional = repo.findById(id);

		if (optional.isEmpty()) {
			throw new UserServiceException("User not found with id: " + id);
		} else {
			return optional.get();
		}
	}
    
    public User updateUser(User user) throws UserServiceException {
		if (repo.existsById(user.getId())) {
			user.setPassword(encoder.encode(user.getPassword()));
			return repo.save(user);
		} else {
			throw new UserServiceException("user not updated with Id: " + user.getId());
		}

	}

//    public Author saveAuthor(Author author){
//        return repo.save(author);
//    }
//    
}
